from odoo import fields, models

class HospitalPatient(models.Model):
    _name = "hospital.patient"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name", tracking=1)
    age = fields.Integer(string="Age", tracking=1)
    ref = fields.Char(string='Patient Code',
                      default=lambda self: self.env['ir.sequence'].next_by_code('hospital.patient.sequence'))
    gender = fields.Selection([
        ('other', 'Other'),
        ('male', 'Male'),
        ('female', 'Female')
    ], string="Gender", default="male", tracking=1)
    active = fields.Boolean(string="Active", default=True, tracking=1)
    reference_id = fields.Reference(
        string='Reference',
        selection='_get_reference_selection',
        tracking=1
    )

    def _get_reference_selection(self):
        # Hàm này trả về danh sách đối tượng Odoo có thể tham chiếu trong trường "reference_id"
        return [('my_module.model1', 'Model 1'), ('my_module.model2', 'Model 2')]

class Model1(models.Model):
    _name = 'my_module.model1'
    _description = 'Model 1'

    name = fields.Char(string='Name', required=True)