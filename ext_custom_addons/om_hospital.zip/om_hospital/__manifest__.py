{
    'name': 'HOSPITAL MANAGEMENT',
    'version': 'ODOO16',
    'category': 'MANAGEMENT',
    'summary': 'APP APP APP ',
    'description': """
    """,
    'depends': ['mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/menu.xml',
        'views/patient_view.xml',
        'views/patient_female_view.xml',

    ],
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
