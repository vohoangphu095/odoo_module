{
    'name': 'OdooRider',
    'version': '1.0',
    'category': 'Accounting/Accounting',
    'summary': 'Check printing commons',
    'description': """
This module offers the basic functionalities to make payments by printing checks.
It must be used as a dependency for modules that provide country-specific check templates.
The check settings are located in the accounting journals configuration page.
    """,
    'depends': [],
    'data': [
        'security/ir.model.access.csv',
        'views/menu_view.xml',
        'views/bike_product_view.xml',
        'views/bike_category_view.xml',
        'views/bike_brands_view.xml',
        'views/bike_customer_view.xml',
        'views/bike_order_view.xml',
        'views/bike_order_item_view.xml',
        'views/bike_staff_view.xml',
        'views/bike_store_view.xml',

    ],
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
