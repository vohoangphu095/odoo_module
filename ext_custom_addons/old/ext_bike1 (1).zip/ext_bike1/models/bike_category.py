from odoo import models, fields

class BikeCategory(models.Model):
    _name = 'bike.category'

    name = fields.Char(string='Ma loai xe', default=lambda self: self.env['ir.sequence'].next_by_code('bike.category.sequence'))
    category_name = fields.Char(string='Ten loai')
