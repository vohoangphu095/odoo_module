from odoo import fields, models

class bikeOrderItem(models.Model):
    _name = 'bike.order.item'

    name = fields.Char(string='Ma hang hoa', default=lambda self: self.env['ir.sequence'].next_by_code('bike.order.item.sequence'))
    order_id = fields.Many2one('bike.order')
    product_id = fields.Many2one('bike.product')
    quantity = fields.Integer(string='So luong')
    discount = fields.Integer(string='Giam gia')
    state = fields.Selection(related='order_id.order_status', string='Trang thai', readonly=True)


class bikeOrder(models.Model):
    _name = 'bike.order'

    name = fields.Char(string='Ma hoa don', default=lambda self: self.env['ir.sequence'].next_by_code('bike.order.sequence'))
    customer_id = fields.Many2one('bike.customer', string='Ma khach hang')
    order_status = fields.Selection([
        ('paid', 'Da thanh toan'),
        ('unpaid', 'Chua thanh toan'),
    ], default='unpaid')
    order_date = fields.Date(string='Ngay dat hang')
    required_date = fields.Date(string='Ngay du kien den')
    shipped_date = fields.Date(string='Ngay giao')
    store_id = fields.Many2one('bike.store', string='Ma cua hang')
    staff_id = fields.Many2one('bike.staff', string='Ma nhan vien')
