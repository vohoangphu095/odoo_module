from odoo import fields,api,models

class bikeStore(models.Model):
    _name='bike.store'

    name=fields.Char(string='Ma kho',default=lambda self:self.env['ir.sequence'].next_by_code('bike.store.sequence'))
    store_name= fields.Char(string='Ten kho')
    store_email= fields.Char(string='Email')
    store_phone= fields.Char(string='So dien thoai')
    store_street= fields.Char(string='Ten duong')
    store_city= fields.Char(string='Thanh pho')
    store_state= fields.Char(string='Dat nuoc')
    store_zip= fields.Char(string='Ma khu vuc')