from odoo import fields, api, models


class bikeCustomer(models.Model):
    _name = 'bike.customer'

    name = fields.Char(string='Ma khach hang ',
                       default=lambda self: self.env['ir.sequence'].next_by_code('bike.customer.squence'))
    customer_name = fields.Char(string='Ho va ten')
    customer_phone = fields.Char(string='So dien thoai')
    customer_email = fields.Char(string='Email')
    customer_street = fields.Char(string='Ten duong')
    customer_city = fields.Char(string='Ten thanh pho')
    customer_state = fields.Char(string='Ten quoc gia')
    customer_zip = fields.Char(string='Ma khu vuc')
