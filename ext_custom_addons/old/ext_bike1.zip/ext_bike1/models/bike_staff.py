from odoo import fields,api,models

class bikeStaff(models.Model):
    _name='bike.staff'

    name=fields.Char(string='Ma nhan vien',default=lambda self:self.env['ir.sequence'].next_by_code('bike.staff.sequence'))
    staff_name= fields.Char(string='Ten nhan vien')
    staff_email= fields.Char(string='Email')
    staff_phone= fields.Char(string='Name')