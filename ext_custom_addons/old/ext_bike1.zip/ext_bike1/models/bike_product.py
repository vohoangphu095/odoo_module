from odoo import models, fields, api


class bikeProduct(models.Model):
    _name = 'bike.product'


    name = fields.Char(string='Ma san pham',default=lambda self: self.env['ir.sequence'].next_by_code('bike.product.sequence'))
    product_name = fields.Char(string='Ten san pham')
    model_year = fields.Date(string='Nam san xuat')
    list_price = fields.Float(string='Don gia')
    category_id = fields.Many2one('bike.category', string='Loai xe')
    brand_id=fields.Many2one('bike.brands',string='Ma thuong hieu')
