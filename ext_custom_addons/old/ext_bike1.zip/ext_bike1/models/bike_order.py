from datetime import datetime, timedelta
from odoo import fields, api, models, exceptions


class BikeOrder(models.Model):
    _name = 'bike.order'
    feedback=fields.Text(string='Y kien phan hoi')
    name = fields.Char(string='Ma hoa don',
                       default=lambda self: self.env['ir.sequence'].next_by_code('bike.order.sequence'),readonly=True)
    customer_id = fields.Many2one('bike.customer', string='Ma khach hang', required=True)
    order_status = fields.Selection([
        ('paid', 'Da thanh toan'),
        ('unpaid', 'Chua thanh toan'),
        ('cancel', 'Da Huy'),
    ], default='unpaid')
    quantity = fields.Selection(
        [('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'),
         ('10', '10')],
        string='So Luong',
        required=True,
        default='1'
    )
    price = fields.Float('Gia thhue', default=100)
    total_price = fields.Float('Tong gia thue', compute='_compute_total_price', store=True)
    order_date = fields.Date(string='Ngay dat hang', required=True)
    required_date = fields.Date(string='Ngay du kien den')
    shipped_date = fields.Date(string='Ngay giao')
    store_id = fields.Many2one('bike.store', string='Ma cua hang', required=True)
    staff_id = fields.Many2one('bike.staff', string='Ma nhan vien')
    product_id = fields.Many2one('bike.product')
    discount = fields.Integer(string='Giam gia')
    note=fields.Text('Ghi chu')
    @api.constrains('order_date')
    def _check_order_date(self):
        for order in self:
            if order.order_date > fields.Date.today():
                raise exceptions.ValidationError("Ngay dat hang phai nho hon hoac bang ngay hien tai!")

    @api.model
    def create(self, vals):
        if not vals.get('customer_id') or not vals.get('order_date') or not vals.get('store_id'):
            raise exceptions.ValidationError("Vui long nhap day du thong tin!")
        return super(BikeOrder, self).create(vals)

    def write(self, vals):
        if 'customer_id' in vals or 'order_date' in vals or 'store_id' in vals:
            if not vals.get('customer_id') or not vals.get('order_date') or not vals.get('store_id'):
                raise exceptions.ValidationError("Vui long nhap day du thong tin!")
        return super(BikeOrder, self).write(vals)

    def update_state_paid(self):
        self.order_status = 'paid'

    @api.onchange('order_status')
    def update_state_unpaid(self):
        if self.order_status == 'paid':
            raise exceptions.ValidationError("Vui long nhap day du thong tin!")
        else:
            self.order_status = 'unpaid'

    def update_state_cancel(self):
        if self.order_status == 'unpaid':
            self.order_status = 'cancel'
        else:
            raise exceptions.ValidationError("Only newly created orders can be canceled!")

    @api.depends('quantity', 'price')
    def _compute_total_price(self):
        for record in self:
            record.total_price = float(record.quantity) * record.price
