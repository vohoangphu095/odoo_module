from odoo import  fields,api,models

class bikeBrands(models.Model):

    _name='bike.brands'

    name=fields.Char(string='Ma nhan hieu',default=lambda self: self.env['ir.sequence'].next_by_code('bike.brands.sequence'))
    brand_name=fields.Char(string='Ten nhan hieu')