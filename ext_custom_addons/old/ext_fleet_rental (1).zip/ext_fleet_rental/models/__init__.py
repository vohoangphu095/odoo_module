# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import bike_rental
from . import bike_vehicle
from . import res_partner
from . import create_invoice

